import { Task, ActivityLog, AuthState } from '@/types';

const STORAGE_KEYS = {
  TASKS: 'taskboard_tasks',
  ACTIVITY_LOG: 'taskboard_activity_log',
  AUTH: 'taskboard_auth',
} as const;

// Safe storage access with error handling
const safeStorage = {
  getItem: (key: string): string | null => {
    try {
      return localStorage.getItem(key);
    } catch (error) {
      console.error('Error reading from localStorage:', error);
      return null;
    }
  },
  setItem: (key: string, value: string): void => {
    try {
      localStorage.setItem(key, value);
    } catch (error) {
      console.error('Error writing to localStorage:', error);
    }
  },
  removeItem: (key: string): void => {
    try {
      localStorage.removeItem(key);
    } catch (error) {
      console.error('Error removing from localStorage:', error);
    }
  },
};

// Tasks storage
export const getTasks = (): Task[] => {
  const tasksJson = safeStorage.getItem(STORAGE_KEYS.TASKS);
  if (!tasksJson) return [];
  
  try {
    return JSON.parse(tasksJson);
  } catch (error) {
    console.error('Error parsing tasks:', error);
    return [];
  }
};

export const saveTasks = (tasks: Task[]): void => {
  safeStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks));
};

// Activity log storage
export const getActivityLog = (): ActivityLog[] => {
  const logJson = safeStorage.getItem(STORAGE_KEYS.ACTIVITY_LOG);
  if (!logJson) return [];
  
  try {
    const log = JSON.parse(logJson);
    return log.slice(-20); // Keep only last 20 activities
  } catch (error) {
    console.error('Error parsing activity log:', error);
    return [];
  }
};

export const saveActivityLog = (log: ActivityLog[]): void => {
  safeStorage.setItem(STORAGE_KEYS.ACTIVITY_LOG, JSON.stringify(log.slice(-20)));
};

export const addActivity = (activity: Omit<ActivityLog, 'id' | 'timestamp'>): void => {
  const log = getActivityLog();
  const newActivity: ActivityLog = {
    ...activity,
    id: Date.now().toString(),
    timestamp: new Date().toISOString(),
  };
  log.push(newActivity);
  saveActivityLog(log);
};

// Auth storage
export const getAuthState = (): AuthState => {
  const authJson = safeStorage.getItem(STORAGE_KEYS.AUTH);
  if (!authJson) return { isAuthenticated: false, rememberMe: false };
  
  try {
    return JSON.parse(authJson);
  } catch (error) {
    console.error('Error parsing auth state:', error);
    return { isAuthenticated: false, rememberMe: false };
  }
};

export const saveAuthState = (state: AuthState): void => {
  safeStorage.setItem(STORAGE_KEYS.AUTH, JSON.stringify(state));
};

export const clearAuthState = (): void => {
  safeStorage.removeItem(STORAGE_KEYS.AUTH);
};

// Reset all data
export const resetAllData = (): void => {
  safeStorage.removeItem(STORAGE_KEYS.TASKS);
  safeStorage.removeItem(STORAGE_KEYS.ACTIVITY_LOG);
};
