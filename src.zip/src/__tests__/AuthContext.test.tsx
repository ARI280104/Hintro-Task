import { renderHook, act } from '@testing-library/react';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { ReactNode } from 'react';

// Mock localStorage
const localStorageMock = (() => {
  let store: Record<string, string> = {};

  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = value;
    },
    removeItem: (key: string) => {
      delete store[key];
    },
    clear: () => {
      store = {};
    },
  };
})();

Object.defineProperty(window, 'localStorage', {
  value: localStorageMock,
});

describe('AuthContext', () => {
  const wrapper = ({ children }: { children: ReactNode }) => (
    <AuthProvider>{children}</AuthProvider>
  );

  beforeEach(() => {
    localStorage.clear();
  });

  it('should start as not authenticated', () => {
    const { result } = renderHook(() => useAuth(), { wrapper });
    expect(result.current.isAuthenticated).toBe(false);
  });

  it('should authenticate with valid credentials', () => {
    const { result } = renderHook(() => useAuth(), { wrapper });

    act(() => {
      const success = result.current.login('intern@demo.com', 'intern123', false);
      expect(success).toBe(true);
    });

    expect(result.current.isAuthenticated).toBe(true);
  });

  it('should not authenticate with invalid credentials', () => {
    const { result } = renderHook(() => useAuth(), { wrapper });

    act(() => {
      const success = result.current.login('wrong@email.com', 'wrongpass', false);
      expect(success).toBe(false);
    });

    expect(result.current.isAuthenticated).toBe(false);
  });

  it('should logout successfully', () => {
    const { result } = renderHook(() => useAuth(), { wrapper });

    act(() => {
      result.current.login('intern@demo.com', 'intern123', false);
    });

    expect(result.current.isAuthenticated).toBe(true);

    act(() => {
      result.current.logout();
    });

    expect(result.current.isAuthenticated).toBe(false);
  });

  it('should persist authentication when remember me is true', () => {
    const { result } = renderHook(() => useAuth(), { wrapper });

    act(() => {
      result.current.login('intern@demo.com', 'intern123', true);
    });

    const authState = JSON.parse(localStorage.getItem('taskboard_auth') || '{}');
    expect(authState.isAuthenticated).toBe(true);
    expect(authState.rememberMe).toBe(true);
  });
});
