import { getTasks, saveTasks, addActivity, getActivityLog } from '@/utils/storage';
import { Task, Priority, ActivityLog } from '@/types';

// Mock localStorage
const localStorageMock = (() => {
  let store: Record<string, string> = {};

  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = value;
    },
    removeItem: (key: string) => {
      delete store[key];
    },
    clear: () => {
      store = {};
    },
  };
})();

Object.defineProperty(window, 'localStorage', {
  value: localStorageMock,
});

describe('Storage Utils', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  describe('getTasks and saveTasks', () => {
    it('should save and retrieve tasks', () => {
      const tasks: Task[] = [
        {
          id: '1',
          title: 'Test Task',
          description: 'Test Description',
          priority: 'high' as Priority,
          dueDate: '2024-12-31',
          tags: ['test'],
          createdAt: new Date().toISOString(),
          status: 'todo',
        },
      ];

      saveTasks(tasks);
      const retrievedTasks = getTasks();

      expect(retrievedTasks).toEqual(tasks);
    });

    it('should return empty array when no tasks exist', () => {
      const tasks = getTasks();
      expect(tasks).toEqual([]);
    });

    it('should handle invalid JSON gracefully', () => {
      localStorage.setItem('taskboard_tasks', 'invalid json');
      const tasks = getTasks();
      expect(tasks).toEqual([]);
    });
  });

  describe('Activity Log', () => {
    it('should add activity to log', () => {
      addActivity({
        action: 'created',
        taskTitle: 'New Task',
      });

      const log = getActivityLog();
      expect(log.length).toBe(1);
      expect(log[0].action).toBe('created');
      expect(log[0].taskTitle).toBe('New Task');
    });

    it('should limit activity log to 20 items', () => {
      // Add 25 activities
      for (let i = 0; i < 25; i++) {
        addActivity({
          action: 'created',
          taskTitle: `Task ${i}`,
        });
      }

      const log = getActivityLog();
      expect(log.length).toBe(20);
    });
  });
});
