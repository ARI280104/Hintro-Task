import { render, screen, fireEvent } from '@testing-library/react';
import TaskCard from '@/components/TaskCard/TaskCard';
import { Task } from '@/types';

describe('TaskCard Component', () => {
  const mockTask: Task = {
    id: '1',
    title: 'Test Task',
    description: 'Test Description',
    priority: 'high',
    dueDate: '2024-12-31',
    tags: ['urgent', 'frontend'],
    createdAt: '2024-01-01T00:00:00.000Z',
    status: 'todo',
  };

  const mockOnEdit = jest.fn();
  const mockOnDelete = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should render task information correctly', () => {
    render(<TaskCard task={mockTask} onEdit={mockOnEdit} onDelete={mockOnDelete} />);

    expect(screen.getByText('Test Task')).toBeInTheDocument();
    expect(screen.getByText('Test Description')).toBeInTheDocument();
    expect(screen.getByText('high')).toBeInTheDocument();
    expect(screen.getByText('urgent')).toBeInTheDocument();
    expect(screen.getByText('frontend')).toBeInTheDocument();
  });

  it('should call onEdit when edit button is clicked', () => {
    render(<TaskCard task={mockTask} onEdit={mockOnEdit} onDelete={mockOnDelete} />);

    const editButton = screen.getByLabelText('Edit task');
    fireEvent.click(editButton);

    expect(mockOnEdit).toHaveBeenCalledWith(mockTask);
  });

  it('should call onDelete when delete button is clicked', () => {
    render(<TaskCard task={mockTask} onEdit={mockOnEdit} onDelete={mockOnDelete} />);

    const deleteButton = screen.getByLabelText('Delete task');
    fireEvent.click(deleteButton);

    expect(mockOnDelete).toHaveBeenCalledWith('1');
  });

  it('should render without description when not provided', () => {
    const taskWithoutDesc = { ...mockTask, description: '' };
    render(<TaskCard task={taskWithoutDesc} onEdit={mockOnEdit} onDelete={mockOnDelete} />);

    expect(screen.queryByText('Test Description')).not.toBeInTheDocument();
  });
});
