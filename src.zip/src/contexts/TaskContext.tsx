'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Task, Priority, TaskStatus } from '@/types';
import { getTasks, saveTasks, addActivity } from '@/utils/storage';

interface TaskContextType {
  tasks: Task[];
  createTask: (task: Omit<Task, 'id' | 'createdAt'>) => void;
  updateTask: (id: string, updates: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  moveTask: (id: string, newStatus: TaskStatus) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  priorityFilter: Priority | 'all';
  setPriorityFilter: (priority: Priority | 'all') => void;
  sortByDueDate: boolean;
  setSortByDueDate: (sort: boolean) => void;
}

const TaskContext = createContext<TaskContextType | undefined>(undefined);

export const TaskProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<Priority | 'all'>('all');
  const [sortByDueDate, setSortByDueDate] = useState(false);

  useEffect(() => {
    const loadedTasks = getTasks();
    setTasks(loadedTasks);
  }, []);

  useEffect(() => {
    saveTasks(tasks);
  }, [tasks]);

  const createTask = (taskData: Omit<Task, 'id' | 'createdAt'>) => {
    const newTask: Task = {
      ...taskData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };
    setTasks((prev) => [...prev, newTask]);
    addActivity({
      action: 'created',
      taskTitle: newTask.title,
    });
  };

  const updateTask = (id: string, updates: Partial<Task>) => {
    setTasks((prev) =>
      prev.map((task) => (task.id === id ? { ...task, ...updates } : task))
    );
    const task = tasks.find((t) => t.id === id);
    if (task) {
      addActivity({
        action: 'edited',
        taskTitle: task.title,
      });
    }
  };

  const deleteTask = (id: string) => {
    const task = tasks.find((t) => t.id === id);
    setTasks((prev) => prev.filter((task) => task.id !== id));
    if (task) {
      addActivity({
        action: 'deleted',
        taskTitle: task.title,
      });
    }
  };

  const moveTask = (id: string, newStatus: TaskStatus) => {
    const task = tasks.find((t) => t.id === id);
    setTasks((prev) =>
      prev.map((task) => (task.id === id ? { ...task, status: newStatus } : task))
    );
    if (task) {
      addActivity({
        action: 'moved',
        taskTitle: task.title,
        details: `Moved to ${newStatus}`,
      });
    }
  };

  return (
    <TaskContext.Provider
      value={{
        tasks,
        createTask,
        updateTask,
        deleteTask,
        moveTask,
        searchQuery,
        setSearchQuery,
        priorityFilter,
        setPriorityFilter,
        sortByDueDate,
        setSortByDueDate,
      }}
    >
      {children}
    </TaskContext.Provider>
  );
};

export const useTasks = () => {
  const context = useContext(TaskContext);
  if (context === undefined) {
    throw new Error('useTasks must be used within a TaskProvider');
  }
  return context;
};
