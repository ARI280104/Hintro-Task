'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { getAuthState, saveAuthState, clearAuthState } from '@/utils/storage';

interface AuthContextType {
  isAuthenticated: boolean;
  login: (email: string, password: string, rememberMe: boolean) => boolean;
  logout: () => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const VALID_CREDENTIALS = {
  email: 'intern@demo.com',
  password: 'intern123',
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const authState = getAuthState();
    if (authState.rememberMe && authState.isAuthenticated) {
      setIsAuthenticated(true);
    }
    setLoading(false);
  }, []);

  const login = (email: string, password: string, rememberMe: boolean): boolean => {
    if (email === VALID_CREDENTIALS.email && password === VALID_CREDENTIALS.password) {
      setIsAuthenticated(true);
      saveAuthState({ isAuthenticated: true, rememberMe });
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
    clearAuthState();
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
