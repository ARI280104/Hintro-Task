'use client';

import { useState, useMemo, useEffect } from 'react';
import { DragDropContext, Droppable, Draggable, DropResult } from '@hello-pangea/dnd';
import { useTasks } from '@/contexts/TaskContext';
import { useAuth } from '@/contexts/AuthContext';
import { Task, TaskStatus, Priority } from '@/types';
import { getActivityLog, resetAllData } from '@/utils/storage';
import { format } from 'date-fns';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import TaskCard from '@/components/TaskCard/TaskCard';
import TaskModal from '@/components/TaskModal/TaskModal';
import styles from './Board.module.css';

const COLUMNS: { id: TaskStatus; title: string; color: string }[] = [
  { id: 'todo', title: 'Todo', color: 'var(--color-status-todo)' },
  { id: 'doing', title: 'Doing', color: 'var(--color-status-doing)' },
  { id: 'done', title: 'Done', color: 'var(--color-status-done)' },
];

export default function BoardPage() {
  const {
    tasks,
    createTask,
    updateTask,
    deleteTask,
    moveTask,
    searchQuery,
    setSearchQuery,
    priorityFilter,
    setPriorityFilter,
    sortByDueDate,
    setSortByDueDate,
  } = useTasks();
  const { logout } = useAuth();
  const router = useRouter();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [defaultStatus, setDefaultStatus] = useState<TaskStatus>('todo');
  const [activityLog, setActivityLog] = useState(getActivityLog());
  const [showActivityLog, setShowActivityLog] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  // Refresh activity log
  useEffect(() => {
    const interval = setInterval(() => {
      setActivityLog(getActivityLog());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Filter and sort tasks
  const filteredTasks = useMemo(() => {
    let filtered = tasks;

    // Search by title
    if (searchQuery) {
      filtered = filtered.filter((task) =>
        task.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Filter by priority
    if (priorityFilter !== 'all') {
      filtered = filtered.filter((task) => task.priority === priorityFilter);
    }

    // Sort by due date
    if (sortByDueDate) {
      filtered = [...filtered].sort((a, b) => {
        if (!a.dueDate && !b.dueDate) return 0;
        if (!a.dueDate) return 1;
        if (!b.dueDate) return -1;
        return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      });
    }

    return filtered;
  }, [tasks, searchQuery, priorityFilter, sortByDueDate]);

  // Group tasks by status
  const tasksByStatus = useMemo(() => {
    const grouped: Record<TaskStatus, Task[]> = {
      todo: [],
      doing: [],
      done: [],
    };

    filteredTasks.forEach((task) => {
      grouped[task.status].push(task);
    });

    return grouped;
  }, [filteredTasks]);

  const handleDragEnd = (result: DropResult) => {
    const { destination, source, draggableId } = result;

    if (!destination) return;
    if (destination.droppableId === source.droppableId && destination.index === source.index) return;

    const newStatus = destination.droppableId as TaskStatus;
    moveTask(draggableId, newStatus);
  };

  const handleCreateTask = (status: TaskStatus) => {
    setEditingTask(null);
    setDefaultStatus(status);
    setIsModalOpen(true);
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setIsModalOpen(true);
  };

  const handleSaveTask = (taskData: Omit<Task, 'id' | 'createdAt'>) => {
    if (editingTask) {
      updateTask(editingTask.id, taskData);
    } else {
      createTask(taskData);
    }
  };

  const handleDeleteTask = (id: string) => {
    if (window.confirm('Are you sure you want to delete this task?')) {
      deleteTask(id);
    }
  };

  const handleLogout = () => {
    logout();
    router.push('/login');
  };

  const handleResetBoard = () => {
    resetAllData();
    window.location.reload();
  };

  return (
    <div className={styles.container}>
      {/* Header */}
      <header className={styles.header}>
        <div className={styles.headerContent}>
          <div className={styles.logo}>
            <svg width="32" height="32" viewBox="0 0 40 40" fill="none">
              <rect width="40" height="40" rx="8" fill="url(#gradient)" />
              <path
                d="M12 20L18 26L28 14"
                stroke="white"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <defs>
                <linearGradient id="gradient" x1="0" y1="0" x2="40" y2="40">
                  <stop offset="0%" stopColor="#ff3366" />
                  <stop offset="100%" stopColor="#ff6b9d" />
                </linearGradient>
              </defs>
            </svg>
            <h1 className={styles.appTitle}>TaskBoard</h1>
          </div>

          <div className={styles.headerActions}>
            <button
              onClick={() => setShowActivityLog(!showActivityLog)}
              className={styles.iconButton}
              aria-label="Activity log"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <path d="M12 8v4l3 3m6-3a9 9 0 1 1-18 0 9 9 0 0 1 18 0z" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
            <button onClick={() => setShowResetConfirm(true)} className={styles.iconButton} aria-label="Reset board">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M21 3v5h-5" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M3 21v-5h5" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
            <button onClick={handleLogout} className={styles.logoutButton}>
              Logout
            </button>
          </div>
        </div>
      </header>

      {/* Filters */}
      <div className={styles.filters}>
        <div className={styles.searchBox}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <circle cx="11" cy="11" r="8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="m21 21-4.35-4.35" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <input
            type="text"
            placeholder="Search tasks..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={styles.searchInput}
          />
        </div>

        <select
          value={priorityFilter}
          onChange={(e) => setPriorityFilter(e.target.value as Priority | 'all')}
          className={styles.filterSelect}
        >
          <option value="all">All Priorities</option>
          <option value="low">Low Priority</option>
          <option value="medium">Medium Priority</option>
          <option value="high">High Priority</option>
        </select>

        <label className={styles.sortToggle}>
          <input
            type="checkbox"
            checked={sortByDueDate}
            onChange={(e) => setSortByDueDate(e.target.checked)}
          />
          <span>Sort by Due Date</span>
        </label>
      </div>

      {/* Board */}
      <DragDropContext onDragEnd={handleDragEnd}>
        <div className={styles.board}>
          {COLUMNS.map((column) => (
            <div key={column.id} className={styles.column}>
              <div className={styles.columnHeader} style={{ borderTopColor: column.color }}>
                <h2 className={styles.columnTitle}>{column.title}</h2>
                <span className={styles.taskCount}>{tasksByStatus[column.id].length}</span>
                <button
                  onClick={() => handleCreateTask(column.id)}
                  className={styles.addButton}
                  aria-label={`Add task to ${column.title}`}
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <line x1="12" y1="5" x2="12" y2="19" strokeWidth="2" strokeLinecap="round"/>
                    <line x1="5" y1="12" x2="19" y2="12" strokeWidth="2" strokeLinecap="round"/>
                  </svg>
                </button>
              </div>

              <Droppable droppableId={column.id}>
                {(provided, snapshot) => (
                  <div
                    ref={provided.innerRef}
                    {...provided.droppableProps}
                    className={`${styles.taskList} ${
                      snapshot.isDraggingOver ? styles.taskListDraggingOver : ''
                    }`}
                  >
                    <AnimatePresence>
                      {tasksByStatus[column.id].map((task, index) => (
                        <Draggable key={task.id} draggableId={task.id} index={index}>
                          {(provided, snapshot) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              {...provided.dragHandleProps}
                              className={snapshot.isDragging ? styles.dragging : ''}
                            >
                              <TaskCard
                                task={task}
                                onEdit={handleEditTask}
                                onDelete={handleDeleteTask}
                              />
                            </div>
                          )}
                        </Draggable>
                      ))}
                    </AnimatePresence>
                    {provided.placeholder}
                    
                    {tasksByStatus[column.id].length === 0 && (
                      <div className={styles.emptyState}>
                        <p>No tasks yet</p>
                      </div>
                    )}
                  </div>
                )}
              </Droppable>
            </div>
          ))}
        </div>
      </DragDropContext>

      {/* Activity Log Sidebar */}
      <AnimatePresence>
        {showActivityLog && (
          <motion.div
            className={styles.activityLogOverlay}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowActivityLog(false)}
          >
            <motion.div
              className={styles.activityLog}
              initial={{ x: 300 }}
              animate={{ x: 0 }}
              exit={{ x: 300 }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className={styles.activityLogHeader}>
                <h3>Activity Log</h3>
                <button onClick={() => setShowActivityLog(false)} className={styles.closeButton}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <line x1="18" y1="6" x2="6" y2="18" strokeWidth="2" strokeLinecap="round"/>
                    <line x1="6" y1="6" x2="18" y2="18" strokeWidth="2" strokeLinecap="round"/>
                  </svg>
                </button>
              </div>
              <div className={styles.activityLogContent}>
                {activityLog.length === 0 ? (
                  <p className={styles.emptyActivity}>No activity yet</p>
                ) : (
                  activityLog.slice().reverse().map((activity) => (
                    <div key={activity.id} className={styles.activityItem}>
                      <div className={styles.activityIcon}>
                        {activity.action === 'created' && '✨'}
                        {activity.action === 'edited' && '✏️'}
                        {activity.action === 'moved' && '➡️'}
                        {activity.action === 'deleted' && '🗑️'}
                      </div>
                      <div className={styles.activityContent}>
                        <p className={styles.activityText}>
                          <strong>{activity.taskTitle}</strong> was {activity.action}
                          {activity.details && ` - ${activity.details}`}
                        </p>
                        <p className={styles.activityTime}>
                          {format(new Date(activity.timestamp), 'MMM dd, HH:mm')}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Reset Confirmation */}
      <AnimatePresence>
        {showResetConfirm && (
          <motion.div
            className={styles.confirmOverlay}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className={styles.confirmDialog}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
            >
              <h3>Reset Board</h3>
              <p>Are you sure you want to reset the board? This will delete all tasks and activity logs.</p>
              <div className={styles.confirmActions}>
                <button onClick={() => setShowResetConfirm(false)} className={styles.cancelButton}>
                  Cancel
                </button>
                <button onClick={handleResetBoard} className={styles.confirmButton}>
                  Reset Board
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Task Modal */}
      <TaskModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingTask(null);
        }}
        onSave={handleSaveTask}
        task={editingTask}
        defaultStatus={defaultStatus}
      />
    </div>
  );
}
