import ProtectedRoute from '@/components/ProtectedRoute/ProtectedRoute';
import { TaskProvider } from '@/contexts/TaskContext';

export default function BoardLayout({ children }: { children: React.ReactNode }) {
  return (
    <ProtectedRoute>
      <TaskProvider>{children}</TaskProvider>
    </ProtectedRoute>
  );
}
